This package implements version 1 of Delve's API and is only
kept here for backwards compatibility. Client.go is the old
client code used by Delve's frontend (delve/cmd/dlv), it is
only preserved here for the backwards compatibility tests in
service/test/integration1_test.go.
